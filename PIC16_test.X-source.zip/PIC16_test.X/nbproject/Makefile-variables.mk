#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=PIC16_test.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/PIC16_test.X.production.hex
